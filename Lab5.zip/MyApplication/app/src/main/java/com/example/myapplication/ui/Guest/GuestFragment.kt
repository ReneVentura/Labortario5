package com.example.myapplication.ui.Guest

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentGuestBinding

class GuestFragment : Fragment() {

    private lateinit var guestViewModel: GuestViewModel
    val guestlist= arrayListOf<String>()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        guestViewModel =
            ViewModelProviders.of(this).get(GuestViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_guest, container, false)
        val binding = DataBindingUtil.inflate<FragmentGuestBinding>(inflater, R.layout.fragment_guest, container, false)
        binding.addButton.setOnClickListener { v: View ->
            v.findNavController().navigate(R.id.action_guestFragment_to_addFragment)
        }
        setHasOptionsMenu(true)
        return binding.root


    }
}
package com.example.myapplication.ui.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentAddBinding
import com.example.myapplication.databinding.FragmentGuestBinding
import com.example.myapplication.ui.register.RegisterFragment

class AddFragment : Fragment() {

    private lateinit var addViewModel: AddViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        addViewModel =
            ViewModelProviders.of(this).get(AddViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_add, container, false)


        val binding = DataBindingUtil.inflate<FragmentAddBinding>(inflater, R.layout.fragment_add, container, false)

        val number= binding.numberText.text.toString()
        val mail= binding.mailText.text.toString()
        binding.saveButton.setOnClickListener { v: View ->
            val fragment= RegisterFragment()
            val bundle= Bundle()
            val name= binding.nameText.text.toString()




            v.findNavController().navigate(R.id.action_addFragment_to_registerFragment)
        }


        setHasOptionsMenu(true)
        return binding.root
    }
    
    }

}